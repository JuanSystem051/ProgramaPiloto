export interface Movie {
    id: number;
    title: string;
    genre: string;
    year: number;
    image: string;
    description: string;
    summary: string;
  }
  